package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exam26Application {

	public static void main(String[] args) {
		SpringApplication.run(Exam26Application.class, args);
	}

}
